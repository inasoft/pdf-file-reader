<!DOCTYPE html>
<html>
<head>
    <title>FTP CONNECTION</title>
</head>
<body>
    <div>
        <h1>FTP CONNECTION</h1>
        <pre>
            <a href="<?php echo e(url('/connect')); ?>" class="form-control">Click Me</a>
        </pre>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ftp-file-manager\resources\views/welcome.blade.php ENDPATH**/ ?>