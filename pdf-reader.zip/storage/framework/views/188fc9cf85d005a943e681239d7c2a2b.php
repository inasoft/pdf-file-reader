<!DOCTYPE html>
<html>
<head>
    <title>Upload PDF</title>
    <style type="text/css">
        .highlighted {
            color: red;
        }
    </style>
</head>
<center>
<body>
    <h2>Upload a PDF</h2>

    <?php if(session('error')): ?>
        <div><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('upload.pdf')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        Upload File : <input type="file" name="pdf" required></br></br>
        <input type="text" name="key" required>
          </br></br>
        <button type="submit">Upload</button>
    </form>

    <?php if($highlightedText): ?>
        <h2>PDF Content</h2>
        <div><?php echo $highlightedText; ?></div>
    <?php endif; ?>
</body>
</center>
</html>
<?php /**PATH C:\xampp\htdocs\ftp-file-manager\resources\views/upload.blade.php ENDPATH**/ ?>