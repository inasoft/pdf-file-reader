<!DOCTYPE html>
<html>
<head>
    <title>View PDF</title>

    <style type="text/css">
    	
    	.highlighted{
    		color: red;
    	}
    </style>
</head>
<body>
    <h2>PDF Content</h2>
    <div><?php echo $highlightedText; ?></div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ftp-file-manager\resources\views/view-pdf.blade.php ENDPATH**/ ?>