<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
use App\Http\Controllers\HostController;
use App\Http\Controllers\FtpController;
use App\Http\Controllers\PDFController;



Route::get('/', function () {
    return view('welcome');
});


Route::get('/upload', [PDFController::class, 'showUploadForm'])->name('upload.form');
Route::post('/upload', [PDFController::class, 'uploadPDF'])->name('upload.pdf');
Route::get('/view-pdf/{filename}', [PDFController::class, 'viewPDF']);

Route::get('/view-pdf/pdfs/{filename}', [PDFController::class, 'viewPDF']);






// Route::get('/connect', [HostController::class, 'showForm'])->name('connect.form');


//Route::get('/pdf/extract-text', [PdfController::class, 'extractText'])->name('pdf.extract-text');


//Route::get('/pdf/extract-text', 'PdfController@extractText')->name('pdf.extract-text');


//Route::get('/connect', 'HostController@showForm')->name('connect.form');

//Route::post('/connect', 'FileController@listFiles')->name('file.list');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
