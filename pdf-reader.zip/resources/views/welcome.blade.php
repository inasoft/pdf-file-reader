<!DOCTYPE html>
<html>
<head>
    <title>FTP CONNECTION</title>
</head>
<body>
    <div>
        <h1>FTP CONNECTION</h1>
        <pre>
            <a href="{{url('/connect')}}" class="form-control">Click Me</a>
        </pre>
    </div>
</body>
</html>
