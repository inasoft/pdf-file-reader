

<!DOCTYPE html>
<html>
<head>
    <title>Sucesss Page</title>

</head>
<body>
    <div>
        <h1>Sucesss Page</h1>
        <pre>
            {{ ($files) }}
        </pre>
    </div>
</body>
</html>
