<!DOCTYPE html>
<html>
<head>
    <title>View PDF</title>

    <style type="text/css">
    	
    	.highlighted{
    		color: red;
    	}
    </style>
</head>
<body>
    <h2>PDF Content</h2>
    <div>{!! $highlightedText !!}</div>
</body>
</html>
