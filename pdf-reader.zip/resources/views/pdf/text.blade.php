<!DOCTYPE html><html><head><title>Extracted Text</title></head><body><div>
            {{ $text }}
        </div></body></html>