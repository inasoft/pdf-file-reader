<!DOCTYPE html>
<html>
<head>
    <title>Upload PDF</title>
    <style type="text/css">
        .highlighted {
            color: red;
        }
    </style>
</head>
<center>
<body>
    <h2>Upload a PDF</h2>

    @if(session('error'))
        <div>{{ session('error') }}</div>
    @endif

    <form action="{{ route('upload.pdf') }}" method="POST" enctype="multipart/form-data">
        @csrf
        Upload File : <input type="file" name="pdf" required></br></br>
        <input type="text" name="key" required>
          </br></br>
        <button type="submit">Upload</button>
    </form>

    @if($highlightedText)
        <h2>PDF Content</h2>
        <div>{!! $highlightedText !!}</div>
    @endif
</body>
</center>
</html>
