<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Spatie\PdfToText\Pdf;


class PDFController extends Controller
{
    
    public function showUploadForm()
    {
    	$highlightedText='';
    	$filename = '';

       return view('upload', compact('highlightedText', 'filename'));

        //return view('upload');
    }

    public function uploadPDF(Request $request)
    {
    	//dd($request->all());
        $request->validate([
            'pdf' => 'required|mimes:pdf|max:2048',
        ]);

        $pdfFile = $request->file('pdf');
        $key = $request->key;

        
        $pdfPath = $pdfFile->store('pdfs', 'public');

		// Redirect to the route URL directly
		return redirect('/view-pdf/' . $pdfPath . '?key=' . $key);
    }

	  public function viewPDF($filename, Request $request)
	{    
		$key = $request->get('key');
	    // Decode the encoded filename to get the actual file path
	    $pdfPath = storage_path('app/public/pdfs/' . urldecode($filename));
	    $text = \Spatie\PdfToText\Pdf::getText($pdfPath, 'C:\Program Files\Git\mingw64\bin\pdftotext.exe');

	    try {
	          $text = \Spatie\PdfToText\Pdf::getText($pdfPath, 'C:\Program Files\Git\mingw64\bin\pdftotext.exe');
              $keywordsToHighlight = [$key];
              $highlightedText = $this->highlightKeywords($text, $keywordsToHighlight);

	    } catch (\Exception $e) {
	        return redirect()->route('upload')->with('error', 'Error extracting text from PDF.');
	    }

         return view('upload', compact('highlightedText', 'filename'));
	}



private function highlightKeywords($text, $keywords)
{
    foreach ($keywords as $keyword) {
        $text = preg_replace("/\b$keyword\b/i", "<span class='highlighted'>$0</span>", $text);
    }

    return $text;
}






}
